Guía Segura — paquete para Netlify Drop
=====================================

Cómo publicar:
1) Arrastra esta carpeta 'guia-segura' completa a https://app.netlify.com/drop
2) Netlify generará una URL pública. Listo.

Imágenes:
- Coloca tus JPG/PNG en: img/
- Las infografías incluidas: infografia1.jpg, infografia2.jpg, infografia3.jpg

Videos:
- Los videos son enlaces que abren YouTube. Cambia los href en la sección #videos y #campana.

Generado el 16 October 2025.
